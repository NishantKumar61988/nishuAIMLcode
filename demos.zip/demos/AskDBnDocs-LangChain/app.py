# Dependencies to install
# 1. Langchain (pip install langchain)
# 2. Flask (pip install flask)
# 3. Tabulate (pip install tabulate)

import csv
import datetime
from decimal import Decimal
import io
from langchain import OpenAI, SQLDatabase, SQLDatabaseChain
from flask import Flask, render_template, request, Response
from langchain.prompts.prompt import PromptTemplate
import pypdf
from tabulate import tabulate
from io import BytesIO, StringIO
from langchain.llms import AzureOpenAI
from flask import Flask, request
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from langchain.text_splitter import CharacterTextSplitter
from langchain.chains import ConversationalRetrievalChain
from langchain.document_loaders import PyPDFLoader
from langchain.memory import ConversationBufferMemory
import PyPDF2

import os
# Please provide your Azure OpenAI API key

os.environ["OPENAI_API_TYPE"] = "azure"
os.environ["OPENAI_API_VERSION"] = "2023-03-15-preview"
os.environ["OPENAI_API_BASE"] = "https://wtwaipoc.openai.azure.com/"
os.environ["OPENAI_API_KEY"] = "50b2a778c1814c18900382f76d1de61c"

# Initialize Flask application
app = Flask(__name__)

# Azure Blob Storage configuration
connection_string = "DefaultEndpointsProtocol=https;AccountName=askdocsfile;AccountKey=wOAXpGRzw2eqkvRrsM1UnwWosrb6jRZ0csc3fmCVukw2N0W97wH20mVoQ1YsE0MmDVOfSv3lTn4s+AStOg37dQ==;EndpointSuffix=core.windows.net"
container_name = "test"
blob_service_client = BlobServiceClient.from_connection_string(
    connection_string)
container_client = blob_service_client.get_container_client(container_name)


# Home route - renders the index.html template for Selecting Ask DB or Ask Docs


@app.route("/")
def home():
    return render_template("index.html")

# SQL route - renders the sql.html template for SQL Database details


@app.route("/sql", methods=["POST"])
def sql():
    return render_template("sql.html")


# docs route - renders the docs.html template for PDF file detials

@app.route("/docs", methods=["POST"])
def docs():
    return render_template("docs.html")

# Route for SQL chat functionality


@app.route("/sqlchat", methods=["POST"])
def sqlchat():
    global username
    username = request.form["username"]
    global password
    password = request.form["password"]
    global server
    server = request.form["server"]
    global database
    database = request.form["database"]
    global table
    table = request.form["table"]

    # Defining prompt and adding skill to enhance the performance of the model

    global defPrompt1
    defPrompt1 = """You are an MS SQL expert. Given an input question, first look for columns in all the mentioned tables and verify that the column names belongs to the correct table before creating a query that includes a join statement and create a syntactically correct MS SQL query to run, then look at the results of the query and return the answer to the input question. Note that you should never perform any operations that could modify the database. This includes UPDATE, DELETE, or INSERT operations. Your job is only to read data and answer questions. You can order the results to return the most informative data in the database. You must query only the columns that are needed to answer the question. Wrap each column name in square brackets ([]) to denote them as delimited identifiers. Pay attention to use only the column names you can see in the tables below. Be careful to not query for columns that do not exist. Also, pay attention to which column is in which table."""

    global defPrompt2
    defPrompt2 = """
    Use the following format:
    Question: "Question here"
    SQLQuery: "SQL Query to run"
    SQLResult: "Result of the SQLQuery"
    """

    # Establish connection to the SQL Server database
    global db
    if table == '':
        db = SQLDatabase.from_uri(
            f"mssql+pyodbc://{username}:{password}@{server}/{database}?driver=ODBC+Driver+17+for+SQL+Server", sample_rows_in_table_info=2)
    else:
        table = [word.strip() for word in table.split(',')]
        db = SQLDatabase.from_uri(
            f"mssql+pyodbc://{username}:{password}@{server}/{database}?driver=ODBC+Driver+17+for+SQL+Server", include_tables=table, sample_rows_in_table_info=2)

    # Create an OpenAI-powered language model and a SQLDatabaseChain
    global llm
    # llm = OpenAI(temperature=0, verbose=True)
    llm = AzureOpenAI(
        deployment_name="test",
        model_name="text-davinci-003",
    )

    # Render chat.html template with user and database information
    return render_template(
        "chat.html",
        user=username,
        server_name=server,
        database_name=database,
        table_name=table
    )

# Route for SQL query execution and result retrieval


@app.route("/sqlresult", methods=["POST"])
def sqlresult():
    query = request.form["message"]
    tb = request.form["customInfo"]

    # _DEFAULT_TEMPLATE = """
    # {table_info}""" + tb + """
    # Question: {input}"""

    _DEFAULT_TEMPLATE = defPrompt1 + tb + defPrompt2 + """

    Only use the following tables:
    {table_info}
    Question: {input}"""

    PROMPT = PromptTemplate(
        input_variables=["input", "table_info"], template=_DEFAULT_TEMPLATE
    )
    db_chain = SQLDatabaseChain.from_llm(
        llm, db, prompt=PROMPT, verbose=True)
    result = db_chain.run(query)
    # print(db.table_info)
    return str(result)


# Route for SQL query execution and Tabular result retrieval

@app.route("/sqlresultRaw", methods=["POST"])
def sqlresultRaw():
    query = request.form["message"]
    tb = request.form["customInfo"]

    # _DEFAULT_TEMPLATE = """
    # {table_info}""" + tb + """
    # Question: {input}"""

    _DEFAULT_TEMPLATE = defPrompt1 + tb + defPrompt2 + """

    Only use the following tables:
    {table_info}
    Question: {input}"""

    PROMPT = PromptTemplate(
        input_variables=["input", "table_info"], template=_DEFAULT_TEMPLATE
    )
    db_chain = SQLDatabaseChain.from_llm(
        llm, db, verbose=True, prompt=PROMPT, return_direct=True, return_intermediate_steps=True, top_k=50000)
    result = db_chain(query)
    global sqlquery
    sqlquery = str(result['intermediate_steps'][1])
    global res
    res = eval(result['intermediate_steps'][3])
    global table
    table = tabulate(eval(result['intermediate_steps'][3]))
    # print(db.table_info)
    return "<b>SQL Query: " + sqlquery + "</b>" + "\n" + table


# Route for Downloading table as a text file

@app.route('/download_txt', methods=["POST"])
def download_txt():
    return Response(
        table,
        mimetype='text/plain',
        headers={'Content-disposition': 'attachment; filename=text_file.txt'})


# Route for Downloading table as a CSV file

@app.route('/download_csv', methods=["POST"])
def download_csv():
    csv_data = StringIO()
    csv_writer = csv.writer(csv_data)

    # Write the tuple data to the CSV file
    for r in res:
        csv_writer.writerow(r)

    # Set the appropriate headers for the response
    headers = {
        'Content-Disposition': 'attachment; filename=CSV_file.csv',
        'Content-Type': 'text/csv'
    }

    return Response(
        csv_data.getvalue(),
        headers=headers,
        mimetype='text/csv'
    )

# Route for Uploading PDF file to Azure Blob storage


@app.route("/docChatUpload", methods=["POST"])
def docChatUpload():
    if 'file' not in request.files:
        return "No file found", 400

    # Extracting file from front-end
    file = request.files['file']
    blob_client = container_client.get_blob_client(file.filename)

    # Uploading file to Blob storage
    blob_client.upload_blob(file)

    # Define the name of the file in Azure Blob Storage
    global blob_name
    blob_name = file.filename

    # Calling PDF function for downloading, chunking, embedding the PDF file
    pdfFunction()
    return render_template("docChat.html", file_name=blob_name)


# Route for Using PDF file which is already uploaded to Azure Blob storage

@app.route("/docChat", methods=["POST"])
def docChat():
    # Extracting File name from front-end
    fileName = request.form["filename"]
    global blob_name
    blob_name = fileName

    # Calling PDF function for downloading, chunking, embedding the PDF file
    pdfFunction()

    # Render the docChat.html and file name
    return render_template("docChat.html", file_name=blob_name)


# Function to download PDF file from Blob storage and convert it into text and chunks,
# and creating embedding and storing them into chroma db as vectors.

def pdfFunction():
    blob_client = blob_service_client.get_blob_client(
        container=container_name, blob=blob_name)

    # Download the PDF file from Blob storage
    pdf_bytes = blob_client.download_blob().readall()

    # Create a file-like object from the bytes data
    file_stream = io.BytesIO(pdf_bytes)

    # Create a PDF reader object
    pdf_reader = PyPDF2.PdfReader(file_stream)

    # Extracting PDF file data to text page by page
    text_data = ""
    for page in pdf_reader.pages:
        text_data += page.extract_text()

    # Splitting text into chunks
    text_splitter = CharacterTextSplitter(
        separator="\n", chunk_size=1000, chunk_overlap=100)
    documents = text_splitter.split_text(text_data)

    # Defining LLM model
    llmdocs = AzureOpenAI(
        deployment_name="test",
        model_name="text-davinci-003",
    )

    # Defining embedding model
    embeddings = OpenAIEmbeddings(deployment="WTW-ADA", chunk_size=1)

    # Creating embeddings from documents and storing them into Vector Database
    vectorstore = Chroma.from_texts(documents, embeddings)

    # Creating a Buffer Memory for stroing chat history
    memory = ConversationBufferMemory(
        memory_key="chat_history", return_messages=True, input_key='question', output_key='answer')

    # Creating ConversationalRetrievalChain with all the parameters
    global conversationResult
    conversationResult = ConversationalRetrievalChain.from_llm(
        llmdocs, vectorstore.as_retriever(), return_source_documents=True, memory=memory)


@app.route("/docsresult", methods=["POST"])
def docsResult():
    # Exracting user Query from front-end
    query = request.form["message"]

    # Sending user query to ConversationalRetrievalChain
    qaResult = conversationResult({"question": query})

    # Returning the results from ConversationalRetrievalChain
    return qaResult["answer"]


# Run the Flask application in debug mode
if __name__ == "__main__":
    app.run(debug=True)
