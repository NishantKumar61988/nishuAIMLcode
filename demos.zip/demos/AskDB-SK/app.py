############################################ README #####################################################

# run the following in command line:-
    # python -m pip install semantic-kernel==0.2.7.dev0
    # pip install Flask
    # pip install pandas
    # pip install asgiref   // allows flask to work with async functions

#########################################################################################################


from flask import Flask, render_template, request,send_from_directory

import semantic_kernel as sk
import sqlite3

import os

import pandas as pd

import time

from semantic_kernel.connectors.ai.open_ai import AzureTextCompletion, AzureTextEmbedding

#initialize an instance of the semantic kernel. Provide OPEN AI KEY in .env file
kernel = sk.Kernel()

azure_api_key = "50b2a778c1814c18900382f76d1de61c"
azure_text_deployment_name = "test"
azure_embed_deployment_name = "WTW-ADA"
azure_endpoint = "https://wtwaipoc.openai.azure.com/"

kernel.add_text_completion_service("dv", AzureTextCompletion(azure_text_deployment_name, azure_endpoint, azure_api_key))
kernel.add_text_embedding_generation_service("ada", AzureTextEmbedding(azure_embed_deployment_name, azure_endpoint, azure_api_key))

# kernel.add_text_completion_service("dv", OpenAITextCompletion("text-davinci-003", api_key, org_id))
# kernel.add_text_embedding_generation_service("ada", OpenAITextEmbedding("text-embedding-ada-002", api_key, org_id))

kernel.register_memory_store(memory_store=sk.memory.VolatileMemoryStore())
kernel.import_skill(sk.core_skills.TextMemorySkill())

# providing the table metadata along with a few sample records from the table
metadata = """

    columns in table form5500datatable :- ["AcknowledgementId,PlanYearBeginDate,
    PlanName,SponsorName,SponsorUsAddress1,SponsorUsCity,
    SponsorUsState,SponsorEin,SponsorPhoneNumber,BusinessCode,
    TotalAssets,TotalExpenses,SignedAdminName"]

    Sample Table Data:-

    AcknowledgementId    PlanYearBeginDate    PlanName    SponsorName    SponsorUsAddress1    SponsorUsCity    SponsorUsState    SponsorEin    SponsorPhoneNumber    BusinessCode    TotalAssets    TotalExpenses    SignedAdminName

    20230130134309NAL0032879522001    2022-01-01    "DUFFY BROTHERS, INC. 401(K) PLAN"    "DUFFY BROTHERS, INC."    N3867 BADEN STREET    COLUMBUS    WI    391033291    9206234160    484120    1717596    20314    PATRICK DUFFY
    20230130134320NAL0034273298001    2022-01-01    TENDER HEARTS HOME CARE 401(K) PLAN    KSTEINBACH INC. DBA TENDER HEARTS HOME CARE    407 CARLUND PARKWAY    NEW YORK MILLS    MN    900177269    2183853466    621510    585880    5682    KERRIE STEINBACH

    ChatBot can have a conversation with you about any topic.
    It can give explicit instructions or say 'I don't know' if it does not have an answer.


    {{$history}}
    User: {{$user_input}}
    ChatBot:
    
    """



sk_prompt = metadata

chat_function = kernel.create_semantic_function(sk_prompt, "policyBot", max_tokens=2000, temperature=0.7, top_p=0.5)

context = kernel.create_new_context()
context["history"] = ""

chat_history = []

session = {}


#function where prompt is passed as input and aa response is generated and returned
def structure_data(rows,columns):
    col_nam = []
    for col in columns:
        col_nam.append(col[0])
        
    data = []
    for row in rows:
        row_data = {}
        cnt = 0
        for col in col_nam:
            row_data[col] = row[cnt]
            cnt += 1
        data.append(row_data)
    return data,col_nam
    

async def prompt_answer(chat_function,prompt,context,chat_history,limit):
    
    # limiting chat history based on the word count limit provided by removing the oldest prompt and response
    temp_chat_history_string = ''.join(chat_history)
    word_count = len(temp_chat_history_string.split(' '))

    while word_count>limit:
        chat_history = chat_history[1:len(chat_history)]
        temp_chat_history_string = ''.join(chat_history)
        word_count = len(temp_chat_history_string.split(' '))

    context["user_input"] = prompt

    bot_answer = await chat_function.invoke_async(context = context)

    #saving the chat history
    chat_history.append(f"\nUser: {context['user_input']}\nChatBot: {str(bot_answer)}\n")

    context['history'] = ''.join(chat_history)

    print("Q: "+prompt)
    print("Answer: "+str(bot_answer))
    print('\n')

    return bot_answer

# initializing python flask app to render the chatbot UI
app = Flask(__name__)
@app.route("/")
def connect():
	return render_template("db_connect.html")

@app.route("/connect", methods=["POST"])
def index():
    database_nm = request.form.get("database")

    username = request.form.get("username")
    password = request.form.get("password")
    server = request.form.get("server")

    session['db_name'] = database_nm
    session['username'] = username
    session['password'] = password
    session['server'] = server
    
    
    # print("Database created and Successfully Connected to Database")

    return render_template("index.html")


# method to take a prompt as input from the user and generate a response
@app.route("/get", methods=["GET","POST"])
async def get_bot_response():
    msg = request.args.get('msg')
    querydb = request.args.get('querydb')

    # print(request.args.get('querydb'))
    response = await prompt_answer(chat_function,msg,context,chat_history,limit = 500)

    tbl_final_str = ''

    if querydb == 'true':
        try:
            sqliteConnection4 = sqlite3.connect(session['db_name'])
            cursor = sqliteConnection4.cursor()
            cursor.execute(str(response))
            records = cursor.fetchmany(5)
            print(records)
            print(cursor.description)

            data,col_nam = structure_data(records,cursor.description)

            records_all = cursor.fetchall()
            data_all,col_nam_all = structure_data(records_all,cursor.description)

            data_csv = pd.DataFrame(data_all)

            file_name = 'result_'+time.strftime("%Y%m%d-%H%M%S")+'.csv'
            file_path = os.getcwd()+'/csv_files/'+file_name
            data_csv.to_csv(file_path)


            tbl_str = ""
            for col in col_nam:
                tbl_str = tbl_str+'\n<th class="table__cell">'+col+'</th>'

            tbl_str_2 =""
            for row in records:
                tbl_str_2 = tbl_str_2+'\n<tr class="table__row">'
                for cell in row:
                    tbl_str_2 = tbl_str_2+'\n<td class="table__cell">'+str(cell)+'</td>'
                tbl_str_2 = tbl_str_2+'\n</tr>'

            download_link = '<a href="/uploads/'+file_name+'">Download CSV File</a>'

            tbl_final_str='<div style="overflow-x:auto;">\n<table class="table">\n<tr class="table__header">'+tbl_str+'\n</tr>'+tbl_str_2+'\n</table>\n</div>\n'+download_link
        except Exception as e:
            tbl_final_str='<div style="color:red"> Generated response has incorrect SQL syntax. Error:-'+str(e)+' </div>'

    table_data = {
        "data":tbl_final_str,
        "query":str(response)
    }

    return table_data

    # return str(response)

@app.route('/uploads/<path:filename>', methods=['GET', 'POST'])
def download(filename):
    uploads = os.getcwd()+'/csv_files'
    return send_from_directory(uploads, filename, as_attachment=True)


if __name__ == "__main__":
    app.run()